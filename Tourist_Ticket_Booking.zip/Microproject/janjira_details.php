<!DOCTYPE html>
<html>
<head>
	<title>Murud Janjira</title>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="details.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

	  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
 
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body style="background-color: #C2FFF9;">
  <div class="co">
		
	
    <h3 id="h31"><span id="sp1" style="color: red">D</span>ream  <span id="sp1" style="color: red">H</span><img id="dt" src="dt.png">lidays</h3>
  
      <ul class="nav justify-content-end mr-5 ">
          <li class="nav-item">
            
          </li>
          <li class="nav-item" >
            <a class="nav-link mr-5" style="color: black;" href="Tourist_Places.html">Home</a>
          </li>
      <li class="nav-item">
        <a class="nav-link mr-5" style="color: black;"href="packages.html">Packages</a>
        </li>
          <li class="nav-item">
            <a class="nav-link mr-5" style="color: black;"href="login.php">Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link mr-5" style="color: black;"href="contact_us.html">Contact Us</a>
          </li>
        </ul>
    </div>

	<div class="container m-4">
    <div class="margin-40"><br><br>
		<h1 style="color: blue;" class="text-center"> Murud Janjira, Maharashtra </h1>
  </div>
		<div class="row mt-5 margin-40">
			<div class="col-md-6 ">
				<div id="carouselExampleControls" class="carousel slide" data-ride="carousel" data-ride="carousel">

          <div class="carousel-inner">
    
    <div class="carousel-item active">

      <img style="width: 700px; height: 400px;" class="d-block w-100" src="janjira1.jpg" alt="First slide">
    </div>
    <div class="carousel-item">

      <img style="width: 700px; height: 400px;" class="d-block w-100" src="janjira2.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">

      <img style="width: 700px; height: 400px;" class="d-block w-100" src="janjira3.jpg" alt="Third slide">
    </div>
    <div class="carousel-item">
      
      <img style="width:700px; height: 400px;" class="d-block w-100" src="janjira4.jpg" alt="Third slide">
    </div>
    <div class="carousel-item">

      <img style="width: 700px; height: 400px;" class="d-block w-100" src="janjira5.jpg" alt="Third slide">
    </div>
    <div class="carousel-item">

      <img style="width: 700px; height: 400px;" class="d-block w-100" src="janjira6.jpg" alt="Third slide">
    </div>
    <div class="carousel-item">

      <img style="width: 700px; height: 400px;" class="d-block w-100" src="janjira7.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <!-- <span class="sr-only">Previous</span> -->
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <!-- <span class="sr-only">Next</span> -->
  </a>
</div>
			</div>
      <div  class="col-md-6">

        <h4>Places to Visit</h4>
        <label>Murud Janjira, Maharashtra  &nbsp;| &nbsp; Janjira Fort &nbsp;| &nbsp; Kasa Fort &nbsp; | &nbsp; Garambi Dam&nbsp;|&nbsp; Murud Beach &nbsp; |&nbsp;  Ahmedganj Palace &nbsp; | &nbsp; Jaigad Fort &nbsp; | &nbsp; Dattatreya Temple &nbsp; | &nbsp; Khokari Tombs &nbsp; |&nbsp; Diveagar &nbsp;| &nbsp; Nagaon &nbsp;|&nbsp; Kolad &nbsp;| &nbsp; Shrihareshware</label>

<br><br>
        <h4>Hotel</h4>
         <label class="h_nm mb-1"> <i class="fas fa-hotel"></i> &nbsp;Majestic Hotel and Resort</label>
        <label><i class="fas fa-map-marker-alt mb-3"></i> &nbsp;&nbsp; Royal Plaza, National Highway 204, Murud, Maharashtra</label>
        
        <div class="know-btn">
        <a href="hotel\index.html" class="aa" >Know More About Hotel</a>
      </div>
      <br>
      <div class="row">
        <div class="col-md-4">
      <div class="price">
        <h4 class="mb-0">Price </h4>
        <label class="pr2"><span class="font-sz"> ₹24999</span> <br><span class="ac-price">₹29999</span ><span class="text-success dis">&nbsp; 7% Off</span></label>
        
      </div>
    </div>
    <div class="col-md-6">
      <div>
        <button type="button" class="btn btn-primary mt-4 p-3 w-100 "  data-bs-toggle="modal" href="#exampleModalToggle" role="button" onclick="modal()"><span class="font-sz1">Book Now</span></button>
      </div>
    </div>
    </div>
     

			</div>
	
      </div>
			<!-- <div  class="col-md-6">
        <br>
      
        <button type="button" class="btn btn-outline-primary btn-lg d-grid gap-1 collapsible ">Places to Visit</button>
      <div class="content">
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
      </div>

<br>
        <h3 id="root" >Hotel</h3>
        <p id="r1">Majestic Hotel and Resort</p>
        
        <div class="know-btn">
        <a href="F:\CSS MicroProject\hotel\index.html" class="btn btn-outline-primary btn-lg d-grid gap-1 ">Know More About Hotel</a>
      </div>

      

			</div>
			 -->
		</div>
	</div>
  <br><br>
  <div class="row mt-5">

  <!-- <h2 id="p">Price : </h2> 
  <p id="pr">25000₹</p>
  <p id="pr1">  17000₹</p> -->
        
  <div class="d-flex justify-content-center   ">


  </div>

  </div>
  </div>

  <div class="modal fade" id="exampleModalToggle" data-backdrop="static" data-keyboard="false" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-g">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalToggleLabel">Book Package</h5>
          <button type="button" onclick="close()" class="btn-close " data-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="#" class="m-4" >
				
            <div class="form-group">
   
              <input type="text" name="user" placeholder="Name" class="form-control" id="user" autocomplete="off">
              <span id="username" class="text-danger font-weight-bold"> </span>
            </div>
  
            <br>
            <div class="form-group">

              <input type="number" name="acc" placeholder="Account Number" class="form-control" id="acc" autocomplete="off">
              <span id="accno" class="text-danger font-weight-bold"> </span>
            </div>
           <br>
            <div class="form-group">
              <input type="number" name="card" placeholder="Card Number" class="form-control" id="card" autocomplete    ="off" maxlength="10">
              <span id="cardno" class="text-danger font-weight-bold"> </span>
            </div>
            <br>
            <div class="form-group">
              <input type="number" name="cvv" placeholder="CVV Number" value=""  class="form-control" id="cvv" autocomplete="off" maxlength="10">
              <span id="cvvno" class="text-danger font-weight-bold"> </span>
            </div>
             <br>
            <div class="form-group">
              <input type="" name="mobile" placeholder="" value="Payable Amount : 24999" disabled class="form-control" id="mobileNumber" autocomplete="off" maxlength="10">
              <span id="mobileno" class="text-danger font-weight-bold"> </span>
            </div>

            <div class="form-group">
              <span id="emailids" class="text-danger font-weight-bold"> </span>
            </div>
    
    
    
          
  
  
        </div>
        <div class="modal-footer">
        <button class="btn btn-outline-danger" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal" data-dismiss="modal">Cancel</button>
        <input type="submit" class="btn btn-success" name="book">
        </form>
        </div>
      </div>
    </div>
  </div>



  <script>
    var coll = document.getElementsByClassName("collapsible");
    var i;
    
    for (i = 0; i < coll.length; i++) {
      coll[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var content = this.nextElementSibling;
        if (content.style.display === "block") {
          content.style.display = "none";
        } else {
          content.style.display = "block";
        }
      });
    }
    </script>
  <script>

    function bookNow(){
        
    }

  </script>
     <script>
      function modal(){
          $(document).ready(function() {
$("#exampleModalToggle").modal('show');
});
      }

      function close() {
          $(document).ready(function() {
$("#exampleModalToggle").modal('hide');
});
      }
</script>

<script>
  function validation(){
    var user=document.getElementById('user').value;
    var acc = document.getElementById('acc').value;
    var card = document.getElementById('card').value;
    var cvv = document.getElementById('cvv').value;
    	if (user == "") {
    		document.getElementById('username').innerHTML="Name required";
    		return false;
    	}
    		if((user.length <= 2) || (user.length > 20)) {
				document.getElementById('username').innerHTML ="Username length must be between 2 to 20";
				return false;	
			}
			if(!isNaN(user)){
				document.getElementById('username').innerHTML ="Only characters are allowed";
				return false;
			}


      if(acc == ""){
				document.getElementById('accno').innerHTML ="Account number required";
				return false;
			}

      if(acc.length < 11){
				document.getElementById('accno').innerHTML ="Account Number must be grater than 12 digits";
				return false;
			}



      if(card == ""){
				document.getElementById('cardno').innerHTML ="Card number required";
				return false;
			}

      if(card.length < 11){
				document.getElementById('cardno').innerHTML ="Card Number must be grater than 12 digits";
				return false;
			}

      if(cvv == ""){
				document.getElementById('cvvno').innerHTML ="CVV number required";
				return false;
			}

      if(cvv.length <3){
				document.getElementById('cvvno').innerHTML ="CVV Number must be grater than 2 digits";
				return false;
			}
      $(document).ready(function() {
      $("#exampleModalToggle").modal('hide');
      });


document.getElementById("user").value = "";
document.getElementById("acc").value = "";
document.getElementById("card").value = "";
document.getElementById("cvv").value = "";

alert("Package booked successfully!");

  }

</script>



<br><br>
<div class="links">
  <a href=""></a>
  <img id="dt1" src="dt.png"><br>
  <p class="copy">Don't Be A Tourist,Be A Traveler.</p><br>
<a href="https://www.facebook.com/"  target="_blank"><i id="insta"  class="fab fa-facebook in1"></i></a>
<a href="https://www.instagram.com/explore/?hl=en" target="_blank"><i id="insta" class= "fab fa-instagram"></i></a>
<a href="https://twitter.com/home" target="_blank"><i id="insta" class="social-icon fab fa-twitter"></i></a>
<a href="https://mail.google.com/mail/u/0/#inbox" target="_blank"><i id="insta"  class="far fa-envelope"></i></a>
    <br>

      <p class="copy1">Copyright © 2021 Dream Holydays. All rights reserved</p>
    <br>
  </div>
</body>
<?php
      if(isset($_GET['book'])){
        $unm=$_GET['user'];
        $acc=$_GET['acc'];
        $card=$_GET['card'];
        $cvv=$_GET['cvv'];
        $pkg="Murud Janjira";

     
        $sub="About Package Booking";
        $body="Hello user!\n Welcome to Dream Holiday Tours and Travels.\n Your Package for $pkg is Successfully Booked...:)\n Price is only 24999/- 7% is off on this deal.\n The Majestic Hotel and Resort is available for you.\nThank you for choosing dream holidays tours and travels";
        // $body="Hello user! Welcome to Dream Holiday Tours and Travels.\n Your Package for $pkg is Successfully Booked...:)\n Price is only 24999/-\nThank you for choosing dream holidays tours and travels";
        $h1="From: appfood052@gmail.com";


        $conn=mysqli_connect("localhost:3306","root","","project");
      if($conn->connect_error){
        die("connection failed");
      
      }
      else{
        if(mail($unm,$sub,$body,$h1)){
          echo "sent";
        }
        $s="insert into bookings values('$unm','$acc','$card','$cvv','$pkg')";
        if(mysqli_query($conn,$s))
        {
          echo "<script>alert('Package Booked Successfully')</script>";
          
        }
        
      }
      require("fpdf/fpdf.php");
          $pdf1=new FPDF();
          $pdf1->AddPage();
          $pdf1->SetFont("Arial","B",8);
          $pdf1->Cell(0,20,"Booking Details",1,1,"C");
          $pdf1->Cell(40,10,"Name",1,0,'C');
          $pdf1->Cell(30,10,"Account Number",1,0,'C');
          $pdf1->Cell(30,10,"Card Number",1,0,'C');
          $pdf1->Cell(30,10,"CVV Number",1,0,'C');
          $pdf1->Cell(60,10,"Package Name",1,1,'C');
        
          $pdf1->Cell(40,10,"$unm",1,0,'C');
          $pdf1->Cell(30,10,"$acc",1,0,'C');
          $pdf1->Cell(30,10,"$card",1,0,'C');
          $pdf1->Cell(30,10,"$cvv",1,0,'C');
          $pdf1->Cell(60,10,"$pkg",1,1,'C');    
          $file1=time().'.pdf';
          $pdf1->output($file1,'D');
     
    }
      
  ?>
</html>