<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
    <br><br><br>    
    <h2 id="h2">Account Details</h2>
    <?php

$con=mysqli_connect("localhost","root","","project");

if($con)
{
    $query="select * from sign_up";

    $result=mysqli_query($con,$query);
    echo "<table style='border: 1px solid black;margin-left: 350px;'>";
    echo "<tr ><td style='border: 1px solid black'>Name</td><td style='border: 1px solid black'>Password</td><td style='border: 1px solid black'>Confirm Password</td><td style='border: 1px solid black'>Mobile No.</td><td style='border: 1px solid black'>Email ID</td></tr>";
    while($row=mysqli_fetch_assoc($result))
    {
        echo "<tr>";
        echo "<td style='border: 1px solid black'>".$row['username']."</td>";
        echo "<td style='border: 1px solid black'>".$row['password']."</td>";
        echo "<td style='border: 1px solid black'>".$row['confirm_password']."</td>";
        echo "<td style='border: 1px solid black'>".$row['mobile_number']."</td>";
        echo "<td style='border: 1px solid black'>".$row['email']."</td>";
        echo "</tr>";
    }
    echo "</table>";
}
?>
<h2 id="h1" style="margin-left: 500px;text-decoration: underline;
    color:blue;">Package Booking Details</h2>

<?php

$con=mysqli_connect("localhost","root","","project");

if($con)
{
    // $s1="delete from sign_up where email='reshmabhosale6581@gmail.com'";
    // mysqli_query($con,$s1);
    $query="select * from bookings";

    $result=mysqli_query($con,$query);
    echo "<table style='border: 1px solid black;margin-left: 400px;'>";
    echo "<tr ><td style='border: 1px solid black'>E-Mail</td><td style='border: 1px solid black'>Package Name</td></tr>";
    while($row=mysqli_fetch_assoc($result))
    {
        echo "<tr>";
        echo "<td style='border: 1px solid black'>".$row['email']."</td>";
        echo "<td style='border: 1px solid black'>".$row['package']."</td>";
        echo "</tr>";
    }
    echo "</table>";
}
?>
</body>


</html>