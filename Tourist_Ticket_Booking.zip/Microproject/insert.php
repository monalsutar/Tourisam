<?php
				$unm=$_GET['user'];
				$pas=$_GET['pass'];
				$conpass=$_GET['conpass'];
				$mobnm=$_GET['mobile'];
				$email=$_GET['email'];
                $sub="About Account Creation";
                $body="Hello $unm! Welcome to Dream Holiday Tours and Travels.\n Your Account is Successfully Created...:)";
                $header="From: appfood052@gmail.com";
                // mail($email,$sub,$body,$header);

				// $conn=mysqli_connect("localhost:3306","root","","project");

				// if($conn->connect_error){
				// 	die("not");
				// }
				// else{
				// 	$s="insert into sign_up values('$unm','$pas','$conpass','$mobnm','$email')";
				// 	mysqli_query($conn,$s);

                //     $d="delete from sign_up where password='123456'";
                //     mysqli_query($conn,$d);
				// 	mysqli_close($conn);
				// }
                
    
    
                
    // require("fpdf/fpdf.php");
    // $pdf=new FPDF();
    // $pdf->AddPage();
    // $pdf->SetFont("Arial","B",8);
    // $pdf->Cell(0,20,"Account Details",1,1,"C");
    // $pdf->Cell(40,10,"UserName",1,0,'C');
    // $pdf->Cell(30,10,"Password",1,0,'C');
    // $pdf->Cell(30,10,"Confirm Password",1,0,'C');
    // $pdf->Cell(30,10,"Mobile No.",1,0,'C');
    // $pdf->Cell(60,10,"Email",1,1,'C');

    // $pdf->Cell(40,10,"$unm",1,0,'C');
    // $pdf->Cell(30,10,"$pas",1,0,'C');
    // $pdf->Cell(30,10,"$conpass",1,0,'C');
    // $pdf->Cell(30,10,"$mobnm",1,0,'C');
    // $pdf->Cell(60,10,"$email",1,1,'C');


    // $file=time().'.pdf';
    //     $pdf->output($file,'D');



			?>