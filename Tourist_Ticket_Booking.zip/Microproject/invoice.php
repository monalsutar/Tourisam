<?php
    $unm="Rupesh";
    $acc="9282923292497";
    $card="2824942828";
    $cvv="823";
    $pkg="mahableswar";
    require("fpdf/fpdf.php");
      $pdf1=new FPDF();
      $pdf1->AddPage();
      $pdf1->SetFont("Arial","B",8);
      $pdf1->Cell(0,20,"Booking Details",1,1,"C");
      $pdf1->Cell(40,10,"Name",1,0,'C');
      $pdf1->Cell(30,10,"Account Number",1,0,'C');
      $pdf1->Cell(30,10,"Card Number",1,0,'C');
      $pdf1->Cell(30,10,"CVV Number",1,0,'C');
      $pdf1->Cell(60,10,"Package Name",1,1,'C');
    
      $pdf1->Cell(40,10,"$unm",1,0,'C');
      $pdf1->Cell(30,10,"$acc",1,0,'C');
      $pdf1->Cell(30,10,"$card",1,0,'C');
      $pdf1->Cell(30,10,"$cvv",1,0,'C');
      $pdf1->Cell(60,10,"$pkg",1,1,'C');    
      $file1=time().'.pdf';
      $pdf1->output($file1,'D');
      
    
?>